package useraccount;

import org.junit.Test;
import org.junit.Assert;

public class UserAccount {

    
    private String[] developers;
    private int[] taskDurations;
    private String[] taskNames;

   
    public UserAccount(String[] developers, int[] taskDurations, String[] taskNames) {
        this.developers = developers;
        this.taskDurations = taskDurations;
        this.taskNames = taskNames;
    }

   
    public String searchTaskByName(String taskName) {
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equals(taskName)) {
                return developers[i] + ", " + taskName;
            }
        }
        return "Task not found";
    }
}

public class UserAccountTest {

    @Test
    public void testSearchTaskByName() {
        String[] developers = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberhalzer"};
        int[] taskDurations = {5, 8, 2, 11};
        String[] taskNames = {"Create Login", "Create Add Features", "Create Reports", "Add Arrays"};

        UserAccount userAccount = new UserAccount(developers, taskDurations, taskNames);

        assertEquals("Mike Smith, Create Login", userAccount.searchTaskByName("Create Login"));
        
    }
}
